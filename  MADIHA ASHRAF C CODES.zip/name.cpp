#include <stdio.h>
int main() {
    printf("Tafazul Zia Makhdoomi\n");
    return 0;
}
