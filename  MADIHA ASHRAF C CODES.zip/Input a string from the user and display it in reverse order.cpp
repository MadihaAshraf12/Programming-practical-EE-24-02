#include <stdio.h>
#include <string.h>
int main() {
    char str[100];
    int length;
    printf("Enter a string: ");
    scanf("%s", str);
    length = strlen(str);
    printf("Reversed string: ");
    for (int i = length - 1; i >= 0; i--) {
        printf("%c", str[i]);
    }
    printf("\n");
    return 0;
}
