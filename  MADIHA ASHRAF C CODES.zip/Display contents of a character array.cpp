#include <stdio.h>
int main() {
    char arr[] = {'H', 'e', 'l', 'l', 'o', '\0'};
    printf("Character array: %s\n", arr);
    return 0;
}
